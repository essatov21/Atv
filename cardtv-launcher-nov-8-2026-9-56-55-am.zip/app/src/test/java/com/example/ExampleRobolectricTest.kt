package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.AppCategory
import com.example.model.CardSuit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("CardTV Launcher", appName)
  }

  @Test
  fun `card suit symbols and categories validation`() {
    assertEquals("♠", CardSuit.SPADES.symbol)
    assertEquals("♥", CardSuit.HEARTS.symbol)
    assertEquals("♦", CardSuit.DIAMONDS.symbol)
    assertEquals("♣", CardSuit.CLUBS.symbol)
    assertNotNull(AppCategory.ALL)
    assertNotNull(AppCategory.STREAMING)
  }
}
