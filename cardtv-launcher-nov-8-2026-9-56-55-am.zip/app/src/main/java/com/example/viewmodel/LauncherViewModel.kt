package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppRepository
import com.example.model.AppCategory
import com.example.model.AppItem
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application.applicationContext)

    private val _allApps = MutableStateFlow<List<AppItem>>(emptyList())
    val allApps: StateFlow<List<AppItem>> = _allApps.asStateFlow()

    private val _activeCategory = MutableStateFlow(AppCategory.ALL)
    val activeCategory: StateFlow<AppCategory> = _activeCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filteredApps = MutableStateFlow<List<AppItem>>(emptyList())
    val filteredApps: StateFlow<List<AppItem>> = _filteredApps.asStateFlow()

    private val _selectedIndex = MutableStateFlow(0)
    val selectedIndex: StateFlow<Int> = _selectedIndex.asStateFlow()

    private val _isTopBarFocused = MutableStateFlow(false)
    val isTopBarFocused: StateFlow<Boolean> = _isTopBarFocused.asStateFlow()

    private val _topBarFocusIndex = MutableStateFlow(0)
    val topBarFocusIndex: StateFlow<Int> = _topBarFocusIndex.asStateFlow()

    private val _idleProgress = MutableStateFlow(0f)
    val idleProgress: StateFlow<Float> = _idleProgress.asStateFlow()

    private val _isExpandedWidget = MutableStateFlow(false)
    val isExpandedWidget: StateFlow<Boolean> = _isExpandedWidget.asStateFlow()

    private val _showDefaultLauncherDialog = MutableStateFlow(false)
    val showDefaultLauncherDialog: StateFlow<Boolean> = _showDefaultLauncherDialog.asStateFlow()

    private val _currentTimeStr = MutableStateFlow("")
    val currentTimeStr: StateFlow<String> = _currentTimeStr.asStateFlow()

    private val _currentDateStr = MutableStateFlow("")
    val currentDateStr: StateFlow<String> = _currentDateStr.asStateFlow()

    private var countdownJob: Job? = null
    private var clockJob: Job? = null

    init {
        loadInstalledApps()
        startClock()
        observeFilters()
    }

    private fun observeFilters() {
        viewModelScope.launch {
            combine(_allApps, _activeCategory, _searchQuery) { apps, category, query ->
                apps.filter { app ->
                    val matchesCategory = when (category) {
                        AppCategory.ALL -> true
                        AppCategory.FAVORITES -> app.isFavorite
                        else -> app.category == category
                    }
                    val matchesQuery = query.isBlank() ||
                            app.label.contains(query, ignoreCase = true) ||
                            app.packageName.contains(query, ignoreCase = true)

                    matchesCategory && matchesQuery
                }
            }.collect { list ->
                _filteredApps.value = list
                if (list.isNotEmpty()) {
                    if (_selectedIndex.value >= list.size) {
                        _selectedIndex.value = 0
                    }
                    restartCountdown()
                } else {
                    _selectedIndex.value = 0
                    _idleProgress.value = 0f
                    _isExpandedWidget.value = false
                }
            }
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            val list = repository.getInstalledApps()
            _allApps.value = list
        }
    }

    private fun startClock() {
        clockJob?.cancel()
        clockJob = viewModelScope.launch {
            val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale("ru"))
            while (isActive) {
                val now = Date()
                _currentTimeStr.value = timeFmt.format(now)
                val rawDate = dateFmt.format(now)
                _currentDateStr.value = rawDate.replaceFirstChar { it.uppercase() }
                delay(1000)
            }
        }
    }

    private fun restartCountdown() {
        countdownJob?.cancel()
        _idleProgress.value = 0f
        _isExpandedWidget.value = false

        if (_isTopBarFocused.value || _filteredApps.value.isEmpty()) {
            return
        }

        countdownJob = viewModelScope.launch {
            val totalMs = 5000L
            val stepMs = 50L
            var elapsed = 0L

            while (elapsed < totalMs && isActive) {
                delay(stepMs)
                elapsed += stepMs
                _idleProgress.value = (elapsed.toFloat() / totalMs).coerceIn(0f, 1f)
            }

            if (isActive && !_isTopBarFocused.value) {
                _isExpandedWidget.value = true
            }
        }
    }

    fun selectNext() {
        val list = _filteredApps.value
        if (list.isEmpty()) return
        _selectedIndex.value = (_selectedIndex.value + 1) % list.size
        restartCountdown()
    }

    fun selectPrevious() {
        val list = _filteredApps.value
        if (list.isEmpty()) return
        _selectedIndex.value = (_selectedIndex.value - 1 + list.size) % list.size
        restartCountdown()
    }

    fun selectIndex(index: Int) {
        val list = _filteredApps.value
        if (index in list.indices) {
            _selectedIndex.value = index
            _isTopBarFocused.value = false
            restartCountdown()
        }
    }

    fun focusTopBar() {
        _isTopBarFocused.value = true
        _isExpandedWidget.value = false
        countdownJob?.cancel()
        _idleProgress.value = 0f
    }

    fun focusCardDeck() {
        _isTopBarFocused.value = false
        restartCountdown()
    }

    fun nextTopBarItem() {
        _topBarFocusIndex.value = (_topBarFocusIndex.value + 1) % 4
    }

    fun previousTopBarItem() {
        _topBarFocusIndex.value = (_topBarFocusIndex.value - 1 + 4) % 4
    }

    fun setTopBarIndex(index: Int) {
        _topBarFocusIndex.value = index
        _isTopBarFocused.value = true
    }

    fun triggerCurrentSelection() {
        if (_isTopBarFocused.value) {
            when (_topBarFocusIndex.value) {
                0 -> repository.openWifiSettings()
                1 -> repository.openBluetoothSettings()
                2 -> repository.openSettings()
                3 -> _showDefaultLauncherDialog.value = true
            }
        } else {
            val currentApp = getSelectedApp()
            if (currentApp != null) {
                repository.launchApp(currentApp)
            }
        }
    }

    fun launchApp(app: AppItem) {
        repository.launchApp(app)
    }

    fun openAppDetails(app: AppItem) {
        repository.openAppDetails(app)
    }

    fun getSelectedApp(): AppItem? {
        val list = _filteredApps.value
        val idx = _selectedIndex.value
        return if (idx in list.indices) list[idx] else null
    }

    fun toggleFavorite(packageName: String) {
        _allApps.value = _allApps.value.map { app ->
            if (app.packageName == packageName) {
                app.copy(isFavorite = !app.isFavorite)
            } else {
                app
            }
        }
    }

    fun setCategory(category: AppCategory) {
        _activeCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openExpandedWidgetNow() {
        _isExpandedWidget.value = true
    }

    fun closeExpandedWidget() {
        _isExpandedWidget.value = false
        restartCountdown()
    }

    fun showDefaultLauncherDialog() {
        _showDefaultLauncherDialog.value = true
    }

    fun hideDefaultLauncherDialog() {
        _showDefaultLauncherDialog.value = false
    }

    fun openHomeSettings() {
        repository.openHomeSettings()
        hideDefaultLauncherDialog()
    }

    fun openWifiSettings() = repository.openWifiSettings()
    fun openBluetoothSettings() = repository.openBluetoothSettings()
    fun openSettings() = repository.openSettings()
}
