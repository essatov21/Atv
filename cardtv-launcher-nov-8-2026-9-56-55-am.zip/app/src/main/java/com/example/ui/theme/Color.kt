package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TvBackgroundDark = Color(0xFF06080F)
val TvBackgroundElevated = Color(0xFF0D121F)
val TvGlassCard = Color(0xCC121929)
val TvGlassCardBorder = Color(0x4000E5FF)
val TvGlassCardHighlight = Color(0x1AFFFFFF)

val NeonCyan = Color(0xFF00E5FF)
val NeonPurple = Color(0xFFBD00FF)
val NeonGold = Color(0xFFFFD700)
val NeonEmerald = Color(0xFF00FFA3)
val NeonCrimson = Color(0xFFFF2A6D)
val NeonBlue = Color(0xFF2979FF)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val CardGlowActive = Color(0x6600E5FF)
val CardGlowInactive = Color(0x1000E5FF)
