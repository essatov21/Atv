package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TvBackgroundDark
import com.example.ui.theme.TvBackgroundElevated

@Composable
fun BackgroundAmbient(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient_glow")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(4500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(TvBackgroundDark)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Center-bottom ambient radial glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.12f * pulse),
                        NeonPurple.copy(alpha = 0.08f * pulse),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, h * 0.65f),
                    radius = w * 0.45f * pulse
                ),
                radius = w * 0.45f * pulse,
                center = Offset(w * 0.5f, h * 0.65f)
            )

            // Top-left subtle purple vignette
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NeonPurple.copy(alpha = 0.07f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.15f, h * 0.15f),
                    radius = w * 0.35f
                ),
                radius = w * 0.35f,
                center = Offset(w * 0.15f, h * 0.15f)
            )

            // Deep TV bottom vignette
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.Transparent,
                        TvBackgroundElevated.copy(alpha = 0.5f),
                        TvBackgroundDark.copy(alpha = 0.95f)
                    )
                )
            )
        }
    }
}
