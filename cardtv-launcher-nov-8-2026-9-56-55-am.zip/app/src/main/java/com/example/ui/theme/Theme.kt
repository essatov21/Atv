package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val TvDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF00363D),
    onPrimaryContainer = NeonCyan,
    secondary = NeonPurple,
    onSecondary = Color.White,
    tertiary = NeonGold,
    background = TvBackgroundDark,
    onBackground = TextPrimary,
    surface = TvBackgroundElevated,
    onSurface = TextPrimary,
    surfaceVariant = TvGlassCard,
    onSurfaceVariant = TextSecondary,
    outline = TvGlassCardBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // TV launchers look best in dark OLED/ambient theme
    dynamicColor: Boolean = false, // Preserve neon playing card aesthetic
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> dynamicDarkColorScheme(context)
        else -> TvDarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
