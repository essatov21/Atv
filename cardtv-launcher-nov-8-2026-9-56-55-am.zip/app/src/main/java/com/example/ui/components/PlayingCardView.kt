package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.example.model.AppItem
import com.example.ui.theme.NeonGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TvGlassCard
import com.example.ui.theme.TvGlassCardBorder

@Composable
fun PlayingCardView(
    app: AppItem,
    isFocused: Boolean,
    idleProgress: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cardSuit = app.cardSuit
    val accentColor = app.neonColor

    val animatedBorderColor = if (isFocused) accentColor else TvGlassCardBorder
    val animatedGlowAlpha by animateFloatAsState(
        targetValue = if (isFocused) 0.5f else 0.05f,
        animationSpec = tween(300),
        label = "glow_alpha"
    )

    val iconBitmap = remember(app.iconDrawable) {
        runCatching {
            app.iconDrawable?.toBitmap(128, 128, Bitmap.Config.ARGB_8888)
        }.getOrNull()
    }

    Box(
        modifier = modifier
            .width(220.dp)
            .height(310.dp)
            .clip(RoundedCornerShape(22.dp))
            .shadow(
                elevation = if (isFocused) 24.dp else 4.dp,
                shape = RoundedCornerShape(22.dp),
                spotColor = accentColor,
                ambientColor = accentColor
            )
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        TvGlassCard,
                        Color(0xFF0F1523).copy(alpha = 0.94f)
                    )
                )
            )
            .border(
                width = if (isFocused) 2.5.dp else 1.dp,
                brush = Brush.linearGradient(
                    colors = if (isFocused) listOf(
                        accentColor,
                        accentColor.copy(alpha = 0.6f),
                        accentColor
                    ) else listOf(
                        TvGlassCardBorder,
                        Color(0x10FFFFFF)
                    )
                ),
                shape = RoundedCornerShape(22.dp)
            )
            .clickable(onClick = onClick)
            .testTag("app_card_${app.packageName}")
    ) {
        // Subtle playing-card watermark in card canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Neon backglow mesh on active card
            if (isFocused) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            accentColor.copy(alpha = animatedGlowAlpha * 0.45f),
                            Color.Transparent
                        ),
                        center = Offset(w * 0.5f, h * 0.4f),
                        radius = w * 0.65f
                    ),
                    radius = w * 0.65f,
                    center = Offset(w * 0.5f, h * 0.4f)
                )
            }

            // Top-left and bottom-right ornate line accents
            drawRoundRect(
                color = if (isFocused) accentColor.copy(alpha = 0.3f) else Color(0x15FFFFFF),
                topLeft = Offset(10.dp.toPx(), 10.dp.toPx()),
                size = Size(w - 20.dp.toPx(), h - 20.dp.toPx()),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        // Card Content Column
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Corner: Rank & Suit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = app.cardRank,
                        color = accentColor,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = cardSuit.symbol,
                        color = cardSuit.primaryColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (app.isTvApp) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0x3300E5FF))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "TV",
                                color = accentColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (app.isFavorite) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Favorite",
                            tint = NeonGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Center: App Icon inside countdown ring when focused
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                contentAlignment = Alignment.Center
            ) {
                // 5-second countdown circular arc
                if (isFocused) {
                    Canvas(modifier = Modifier.size(108.dp)) {
                        val strokeWidth = 3.dp.toPx()
                        // Track
                        drawCircle(
                            color = Color(0x30FFFFFF),
                            style = Stroke(strokeWidth)
                        )
                        // Progress arc
                        if (idleProgress > 0f) {
                            drawArc(
                                brush = Brush.sweepGradient(
                                    listOf(accentColor, NeonGold, accentColor)
                                ),
                                startAngle = -90f,
                                sweepAngle = 360f * idleProgress,
                                useCenter = false,
                                style = Stroke(strokeWidth, cap = StrokeCap.Round)
                            )
                        }
                    }
                }

                // Icon Container
                Box(
                    modifier = Modifier
                        .size(86.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF1E283D),
                                    Color(0xFF0F1422)
                                )
                            )
                        )
                        .border(
                            width = if (isFocused) 1.5.dp else 1.dp,
                            color = if (isFocused) accentColor.copy(alpha = 0.7f) else TvGlassCardBorder,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (iconBitmap != null) {
                        Image(
                            bitmap = iconBitmap.asImageBitmap(),
                            contentDescription = app.label,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Tv,
                            contentDescription = app.label,
                            tint = accentColor,
                            modifier = Modifier.size(46.dp)
                        )
                    }
                }
            }

            // Bottom Section: App Title, Category, and Bottom-Right Rank/Suit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column(
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Text(
                        text = app.label,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (isFocused && idleProgress > 0f) {
                            val secsLeft = (5 - (idleProgress * 5).toInt()).coerceAtLeast(1)
                            "Инфо через ${secsLeft}с…"
                        } else {
                            app.category.title
                        },
                        color = if (isFocused && idleProgress > 0f) accentColor else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = if (isFocused) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 1
                    )
                }

                // Inverted Bottom-Right Card Badge
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.rotate(180f)
                ) {
                    Text(
                        text = app.cardRank,
                        color = accentColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = cardSuit.symbol,
                        color = cardSuit.primaryColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
