package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCategory
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TvGlassCard
import com.example.ui.theme.TvGlassCardBorder

@Composable
fun TopControlBar(
    timeString: String,
    dateString: String,
    isTopBarFocused: Boolean,
    focusedIndex: Int,
    activeCategory: AppCategory,
    onCategorySelected: (AppCategory) -> Unit,
    onWifiClick: () -> Unit,
    onBluetoothClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onDefaultLauncherClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Live Clock Section
            Column {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = if (timeString.isNotBlank()) timeString else "00:00:00",
                        color = TextPrimary,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        modifier = Modifier.testTag("live_clock_time")
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Box(
                        modifier = Modifier
                            .padding(bottom = 6.dp)
                            .size(8.dp)
                            .background(NeonCyan, CircleShape)
                    )
                }
                Text(
                    text = if (dateString.isNotBlank()) dateString else "Android TV",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.testTag("live_clock_date")
                )
            }

            // Quick Control Buttons (Wi-Fi, Bluetooth, Settings, Make Default)
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TopActionButton(
                    icon = Icons.Default.Wifi,
                    label = "Wi-Fi",
                    isFocused = isTopBarFocused && focusedIndex == 0,
                    onClick = onWifiClick,
                    tag = "btn_wifi"
                )
                TopActionButton(
                    icon = Icons.Default.Bluetooth,
                    label = "Bluetooth",
                    isFocused = isTopBarFocused && focusedIndex == 1,
                    onClick = onBluetoothClick,
                    tag = "btn_bluetooth"
                )
                TopActionButton(
                    icon = Icons.Default.Settings,
                    label = "Настройки",
                    isFocused = isTopBarFocused && focusedIndex == 2,
                    onClick = onSettingsClick,
                    tag = "btn_settings"
                )
                TopActionButton(
                    icon = Icons.Default.Tv,
                    label = "Сделать основным",
                    isFocused = isTopBarFocused && focusedIndex == 3,
                    onClick = onDefaultLauncherClick,
                    accentColor = NeonGold,
                    tag = "btn_make_default_launcher"
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Categories Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppCategory.entries.forEach { category ->
                val isSelected = activeCategory == category
                CategoryChip(
                    category = category,
                    isSelected = isSelected,
                    onClick = { onCategorySelected(category) }
                )
            }
        }
    }
}

@Composable
private fun TopActionButton(
    icon: ImageVector,
    label: String,
    isFocused: Boolean,
    onClick: () -> Unit,
    accentColor: Color = NeonCyan,
    tag: String
) {
    val scale by animateFloatAsState(targetValue = if (isFocused) 1.1f else 1.0f, label = "btn_scale")
    val borderColor by animateColorAsState(
        targetValue = if (isFocused) accentColor else TvGlassCardBorder,
        label = "btn_border"
    )
    val bgColor by animateColorAsState(
        targetValue = if (isFocused) accentColor.copy(alpha = 0.22f) else TvGlassCard,
        label = "btn_bg"
    )

    Row(
        modifier = Modifier
            .scale(scale)
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(
                width = if (isFocused) 2.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isFocused) accentColor else TextPrimary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            color = if (isFocused) TextPrimary else TextSecondary,
            fontSize = 13.sp,
            fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun CategoryChip(
    category: AppCategory,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (isSelected) {
        Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.35f), NeonPurple.copy(alpha = 0.35f)))
    } else {
        Brush.horizontalGradient(listOf(TvGlassCard, TvGlassCard))
    }
    val border = if (isSelected) NeonCyan else TvGlassCardBorder

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("category_chip_${category.name}")
    ) {
        Text(
            text = category.title,
            color = if (isSelected) NeonCyan else TextMuted,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
