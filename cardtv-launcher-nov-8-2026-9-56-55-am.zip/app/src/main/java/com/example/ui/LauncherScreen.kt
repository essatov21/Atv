package com.example.ui

import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BackgroundAmbient
import com.example.ui.components.DefaultLauncherDialog
import com.example.ui.components.ExpandedAppWidget
import com.example.ui.components.RadialCarousel
import com.example.ui.components.TopControlBar
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TvGlassCard
import com.example.ui.theme.TvGlassCardBorder
import com.example.viewmodel.LauncherViewModel

@Composable
fun LauncherScreen(
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val filteredApps by viewModel.filteredApps.collectAsState()
    val selectedIndex by viewModel.selectedIndex.collectAsState()
    val isTopBarFocused by viewModel.isTopBarFocused.collectAsState()
    val topBarFocusIndex by viewModel.topBarFocusIndex.collectAsState()
    val idleProgress by viewModel.idleProgress.collectAsState()
    val isExpandedWidget by viewModel.isExpandedWidget.collectAsState()
    val showDefaultDialog by viewModel.showDefaultLauncherDialog.collectAsState()
    val timeString by viewModel.currentTimeStr.collectAsState()
    val dateString by viewModel.currentDateStr.collectAsState()
    val activeCategory by viewModel.activeCategory.collectAsState()

    val selectedApp = viewModel.getSelectedApp()
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    // Handle back button on Android TV remote
    BackHandler(enabled = isExpandedWidget || showDefaultDialog || isTopBarFocused) {
        when {
            showDefaultDialog -> viewModel.hideDefaultLauncherDialog()
            isExpandedWidget -> viewModel.closeExpandedWidget()
            isTopBarFocused -> viewModel.focusCardDeck()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .focusRequester(focusRequester)
            .focusable()
            .onPreviewKeyEvent { event ->
                if (event.nativeKeyEvent.action == KeyEvent.ACTION_DOWN) {
                    when (event.nativeKeyEvent.keyCode) {
                        KeyEvent.KEYCODE_DPAD_LEFT -> {
                            if (isTopBarFocused) {
                                viewModel.previousTopBarItem()
                            } else {
                                if (isExpandedWidget) viewModel.closeExpandedWidget()
                                viewModel.selectPrevious()
                            }
                            true
                        }

                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            if (isTopBarFocused) {
                                viewModel.nextTopBarItem()
                            } else {
                                if (isExpandedWidget) viewModel.closeExpandedWidget()
                                viewModel.selectNext()
                            }
                            true
                        }

                        KeyEvent.KEYCODE_DPAD_UP -> {
                            if (!isTopBarFocused && !isExpandedWidget) {
                                viewModel.focusTopBar()
                                true
                            } else {
                                false
                            }
                        }

                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (isTopBarFocused) {
                                viewModel.focusCardDeck()
                                true
                            } else {
                                false
                            }
                        }

                        KeyEvent.KEYCODE_DPAD_CENTER,
                        KeyEvent.KEYCODE_ENTER,
                        KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                            if (isExpandedWidget) {
                                val current = viewModel.getSelectedApp()
                                if (current != null) viewModel.launchApp(current)
                            } else {
                                viewModel.triggerCurrentSelection()
                            }
                            true
                        }

                        KeyEvent.KEYCODE_INFO,
                        KeyEvent.KEYCODE_MENU -> {
                            if (isExpandedWidget) {
                                viewModel.closeExpandedWidget()
                            } else {
                                viewModel.openExpandedWidgetNow()
                            }
                            true
                        }

                        KeyEvent.KEYCODE_BACK -> {
                            if (showDefaultDialog) {
                                viewModel.hideDefaultLauncherDialog()
                                true
                            } else if (isExpandedWidget) {
                                viewModel.closeExpandedWidget()
                                true
                            } else if (isTopBarFocused) {
                                viewModel.focusCardDeck()
                                true
                            } else {
                                false
                            }
                        }

                        else -> false
                    }
                } else {
                    false
                }
            }
            .testTag("launcher_screen_root")
    ) {
        // Futuristic Ambient TV Background
        BackgroundAmbient()

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Clock + Wi-Fi + Bluetooth + Settings + Default Home Button + Categories
            TopControlBar(
                timeString = timeString,
                dateString = dateString,
                isTopBarFocused = isTopBarFocused,
                focusedIndex = topBarFocusIndex,
                activeCategory = activeCategory,
                onCategorySelected = { viewModel.setCategory(it) },
                onWifiClick = {
                    viewModel.setTopBarIndex(0)
                    viewModel.openWifiSettings()
                },
                onBluetoothClick = {
                    viewModel.setTopBarIndex(1)
                    viewModel.openBluetoothSettings()
                },
                onSettingsClick = {
                    viewModel.setTopBarIndex(2)
                    viewModel.openSettings()
                },
                onDefaultLauncherClick = {
                    viewModel.setTopBarIndex(3)
                    viewModel.showDefaultLauncherDialog()
                }
            )

            // Center: Radial Carousel
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                if (filteredApps.isEmpty()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = NeonCyan)
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Загрузка колоды приложений…",
                            color = TextSecondary,
                            fontSize = 15.sp
                        )
                    }
                } else {
                    RadialCarousel(
                        apps = filteredApps,
                        selectedIndex = selectedIndex,
                        isTopBarFocused = isTopBarFocused,
                        idleProgress = idleProgress,
                        onCardClick = { index ->
                            if (index == selectedIndex && !isTopBarFocused) {
                                val app = viewModel.getSelectedApp()
                                if (app != null) viewModel.launchApp(app)
                            } else {
                                viewModel.selectIndex(index)
                            }
                        },
                        onSwipeNext = { viewModel.selectNext() },
                        onSwipePrev = { viewModel.selectPrevious() }
                    )
                }
            }

            // Bottom Navigation TV HUD & Tips
            BottomHud(
                totalApps = filteredApps.size,
                currentIndex = selectedIndex,
                selectedApp = selectedApp,
                onPrevClick = { viewModel.selectPrevious() },
                onNextClick = { viewModel.selectNext() },
                onLaunchClick = {
                    val app = viewModel.getSelectedApp()
                    if (app != null) viewModel.launchApp(app)
                },
                onInfoClick = { viewModel.openExpandedWidgetNow() },
                onReloadClick = { viewModel.loadInstalledApps() }
            )
        }

        // Expanded 5-Second Trigger App Widget
        ExpandedAppWidget(
            app = selectedApp,
            isVisible = isExpandedWidget,
            onLaunchClick = {
                if (selectedApp != null) viewModel.launchApp(selectedApp)
            },
            onToggleFavorite = {
                if (selectedApp != null) viewModel.toggleFavorite(selectedApp.packageName)
            },
            onAppDetailsClick = {
                if (selectedApp != null) viewModel.openAppDetails(selectedApp)
            },
            onCloseClick = { viewModel.closeExpandedWidget() }
        )

        // Make Default Launcher Dialog
        DefaultLauncherDialog(
            isVisible = showDefaultDialog,
            onOpenSettingsClick = { viewModel.openHomeSettings() },
            onDismiss = { viewModel.hideDefaultLauncherDialog() }
        )
    }
}

@Composable
private fun BottomHud(
    totalApps: Int,
    currentIndex: Int,
    selectedApp: com.example.model.AppItem?,
    onPrevClick: () -> Unit,
    onNextClick: () -> Unit,
    onLaunchClick: () -> Unit,
    onInfoClick: () -> Unit,
    onReloadClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Navigation & Remote Key Hints
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(TvGlassCard)
                    .border(1.dp, TvGlassCardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "← / → Вращать колоду",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(TvGlassCard)
                    .border(1.dp, TvGlassCardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "OK / Enter Запуск",
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(TvGlassCard)
                    .border(1.dp, TvGlassCardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "5 сек = Детали карты",
                    color = NeonGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Center / Right: Quick Touch and Controller Shortcuts
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (totalApps > 0) {
                Text(
                    text = "${currentIndex + 1} / $totalApps",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(end = 4.dp)
                )
            }

            IconButton(
                onClick = onPrevClick,
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(TvGlassCard)
                    .border(1.dp, TvGlassCardBorder, CircleShape)
                    .testTag("btn_prev_card")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Предыдущая карта",
                    tint = TextPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }

            IconButton(
                onClick = onNextClick,
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(TvGlassCard)
                    .border(1.dp, TvGlassCardBorder, CircleShape)
                    .testTag("btn_next_card")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Следующая карта",
                    tint = TextPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }

            IconButton(
                onClick = onInfoClick,
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(TvGlassCard)
                    .border(1.dp, TvGlassCardBorder, CircleShape)
                    .testTag("btn_manual_info")
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Информация",
                    tint = NeonCyan,
                    modifier = Modifier.size(16.dp)
                )
            }

            IconButton(
                onClick = onReloadClick,
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(TvGlassCard)
                    .border(1.dp, TvGlassCardBorder, CircleShape)
                    .testTag("btn_reload_apps")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Обновить список",
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
