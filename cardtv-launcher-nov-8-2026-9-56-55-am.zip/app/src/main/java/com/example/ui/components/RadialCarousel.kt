package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.model.AppItem
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RadialCarousel(
    apps: List<AppItem>,
    selectedIndex: Int,
    isTopBarFocused: Boolean,
    idleProgress: Float,
    onCardClick: (Int) -> Unit,
    onSwipeNext: () -> Unit,
    onSwipePrev: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (apps.isEmpty()) {
        return
    }

    val total = apps.size
    // Smooth continuous animated position
    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = 0.82f,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "carousel_rotation"
    )

    var accumulatedDrag by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(total) {
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, dragAmount ->
                        accumulatedDrag += dragAmount
                        if (accumulatedDrag < -60f) {
                            onSwipeNext()
                            accumulatedDrag = 0f
                        } else if (accumulatedDrag > 60f) {
                            onSwipePrev()
                            accumulatedDrag = 0f
                        }
                    },
                    onDragEnd = {
                        accumulatedDrag = 0f
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // Draw cards in depth order: furthest cards first, central card last
        apps.forEachIndexed { i, app ->
            // Compute circular difference
            val rawDiff = i - animatedIndex
            // Normalize into [-total/2, total/2]
            var diff = rawDiff
            while (diff < -total / 2f) diff += total
            while (diff > total / 2f) diff -= total

            val absDiff = abs(diff)

            // Only render cards visible in the field of view (-3.8 to 3.8)
            if (absDiff <= 3.8f) {
                val isSelectedCard = i == selectedIndex && !isTopBarFocused

                // Radial circle mathematics:
                // angle in radians: 24 degrees per card
                val angleDeg = diff * 22f
                val angleRad = Math.toRadians(angleDeg.toDouble())

                // Radius of arc
                val radiusPx = 620f
                val transX = (sin(angleRad) * radiusPx).toFloat()
                // Curve slightly backward/downward along circular path
                val transY = ((1.0 - cos(angleRad)) * 75f).toFloat() + (if (isSelectedCard) -28f else 12f)

                // Scale: selected card reaches 1.3f scale, distant cards recede to 0.72f
                val targetScale = if (absDiff < 0.3f) {
                    val progressToCenter = 1f - (absDiff / 0.3f)
                    1.0f + 0.30f * progressToCenter
                } else {
                    (1.0f - (absDiff * 0.08f)).coerceIn(0.70f, 1.0f)
                }

                // 3D perspective rotation
                val rotY = -angleDeg * 0.65f
                val rotZ = angleDeg * 0.15f

                // Alpha fade in perspective
                val alpha = (1.0f - (absDiff * 0.18f)).coerceIn(0.25f, 1.0f)
                val cardZIndex = (100f - absDiff * 10f)

                Box(
                    modifier = Modifier
                        .zIndex(cardZIndex)
                        .graphicsLayer {
                            translationX = transX * density
                            translationY = transY * density
                            scaleX = targetScale
                            scaleY = targetScale
                            rotationY = rotY
                            rotationZ = rotZ
                            cameraDistance = 16f * density
                            this.alpha = alpha
                        }
                ) {
                    PlayingCardView(
                        app = app,
                        isFocused = isSelectedCard,
                        idleProgress = if (isSelectedCard) idleProgress else 0f,
                        onClick = {
                            if (i == selectedIndex) {
                                onCardClick(i)
                            } else {
                                onCardClick(i)
                            }
                        }
                    )
                }
            }
        }
    }
}
