package com.example.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.example.model.AppCategory
import com.example.model.AppItem
import com.example.model.CardSuit
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonPurple
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppRepository(private val context: Context) {

    private val ranks = listOf("A", "K", "Q", "J", "10", "9", "8", "7", "6")
    private val suits = CardSuit.entries.toTypedArray()
    private val neonPalette = listOf(NeonCyan, NeonPurple, NeonGold, NeonEmerald, NeonCrimson, NeonBlue)

    suspend fun getInstalledApps(): List<AppItem> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val myPackageName = context.packageName

        val tvIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        }
        val mobileIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PackageManager.MATCH_ALL
        } else {
            0
        }

        val tvApps = runCatching { pm.queryIntentActivities(tvIntent, flags) }.getOrDefault(emptyList())
        val mobileApps = runCatching { pm.queryIntentActivities(mobileIntent, flags) }.getOrDefault(emptyList())

        val combined = (tvApps + mobileApps)
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != myPackageName }

        val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

        val realItems = combined.mapIndexed { index, resolveInfo ->
            val pkg = resolveInfo.activityInfo.packageName
            val label = runCatching { resolveInfo.loadLabel(pm).toString() }.getOrDefault(pkg)
            val icon = runCatching { resolveInfo.loadIcon(pm) }.getOrNull()

            var verName = "1.0"
            var verCode = 1L
            var isSystem = false
            var installDateStr = dateFormat.format(Date())
            var updateDateStr = dateFormat.format(Date())

            runCatching {
                val pkgInfo = pm.getPackageInfo(pkg, 0)
                verName = pkgInfo.versionName ?: "1.0"
                verCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pkgInfo.longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    pkgInfo.versionCode.toLong()
                }
                isSystem = (pkgInfo.applicationInfo?.flags?.and(ApplicationInfo.FLAG_SYSTEM)) != 0
                installDateStr = dateFormat.format(Date(pkgInfo.firstInstallTime))
                updateDateStr = dateFormat.format(Date(pkgInfo.lastUpdateTime))
            }

            val isTv = tvApps.any { it.activityInfo.packageName == pkg }
            val suit = suits[Math.abs((pkg.hashCode() + index) % suits.size)]
            val rank = ranks[Math.abs((pkg.hashCode() / 7 + index) % ranks.size)]
            val neon = neonPalette[Math.abs((pkg.hashCode() + index) % neonPalette.size)]
            val category = detectCategory(pkg, label, isTv)

            AppItem(
                id = pkg,
                label = label,
                packageName = pkg,
                activityName = resolveInfo.activityInfo.name,
                iconDrawable = icon,
                versionName = verName,
                versionCode = verCode,
                isTvApp = isTv,
                isSystemApp = isSystem,
                isFavorite = false,
                cardSuit = suit,
                cardRank = rank,
                neonColor = neon,
                category = category,
                installDate = installDateStr,
                lastUpdateTime = updateDateStr,
                description = "Пакет: $pkg • Версия: $verName ($verCode)"
            )
        }

        if (realItems.size < 6) {
            // Complement with curated Android TV apps
            val dummyTemplates = getCuratedTvApps(realItems.map { it.packageName }.toSet())
            (realItems + dummyTemplates).distinctBy { it.packageName }
        } else {
            realItems
        }
    }

    private fun detectCategory(pkg: String, label: String, isTv: Boolean): AppCategory {
        val lower = (pkg + " " + label).lowercase(Locale.ROOT)
        return when {
            lower.contains("youtube") || lower.contains("netflix") || lower.contains("cinema") ||
                    lower.contains("kino") || lower.contains("tv") || lower.contains("stream") ||
                    lower.contains("twitch") || lower.contains("video") || lower.contains("movie") -> AppCategory.STREAMING

            lower.contains("music") || lower.contains("player") || lower.contains("audio") ||
                    lower.contains("vlc") || lower.contains("sound") || lower.contains("radio") ||
                    lower.contains("spotify") -> AppCategory.MEDIA

            lower.contains("game") || lower.contains("play") && !lower.contains("store") ||
                    lower.contains("arcade") || lower.contains("racing") -> AppCategory.GAMES

            lower.contains("settings") || lower.contains("file") || lower.contains("cleaner") ||
                    lower.contains("browser") || lower.contains("chrome") || lower.contains("tool") ||
                    lower.contains("system") -> AppCategory.TOOLS

            else -> if (isTv) AppCategory.STREAMING else AppCategory.ALL
        }
    }

    private fun getCuratedTvApps(existingPackages: Set<String>): List<AppItem> {
        val curations = listOf(
            CuratedApp("YouTube TV", "com.google.android.youtube.tv", "Видеохостинг и стриминг контента в 4K Ultra HD", AppCategory.STREAMING, CardSuit.HEARTS, "A", NeonCrimson),
            CuratedApp("Кинопоиск", "ru.kinopoisk.tv", "Фильмы, сериалы и трансляции телеканалов онлайн", AppCategory.STREAMING, CardSuit.DIAMONDS, "K", NeonGold),
            CuratedApp("VLC Player", "org.videolan.vlc", "Универсальный медиаплеер с поддержкой всех видеокодеков", AppCategory.MEDIA, CardSuit.CLUBS, "Q", NeonEmerald),
            CuratedApp("Twitch TV", "tv.twitch.android.app", "Прямые трансляции киберспорта, гейминга и шоу", AppCategory.STREAMING, CardSuit.SPADES, "J", NeonPurple),
            CuratedApp("Google Play Store", "com.android.vending", "Каталог приложений и игр для смарт ТВ", AppCategory.TOOLS, CardSuit.SPADES, "10", NeonCyan),
            CuratedApp("Files Explorer", "com.android.documentsui", "Файловый менеджер и накопители для Android TV", AppCategory.TOOLS, CardSuit.CLUBS, "9", NeonBlue)
        )

        val filtered = curations.filterNot { existingPackages.contains(it.packageName) }
        val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val today = dateFormat.format(Date())

        return filtered.map { cur ->
            AppItem(
                id = cur.packageName,
                label = cur.label,
                packageName = cur.packageName,
                activityName = null,
                iconDrawable = null,
                versionName = "2.4.0",
                versionCode = 240L,
                isTvApp = true,
                isSystemApp = false,
                isFavorite = false,
                cardSuit = cur.suit,
                cardRank = cur.rank,
                neonColor = cur.neon,
                category = cur.category,
                installDate = today,
                lastUpdateTime = today,
                description = cur.desc
            )
        }
    }

    private data class CuratedApp(
        val label: String,
        val packageName: String,
        val desc: String,
        val category: AppCategory,
        val suit: CardSuit,
        val rank: String,
        val neon: androidx.compose.ui.graphics.Color
    )

    fun launchApp(app: AppItem): Boolean {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                true
            } else {
                // If not directly installed, open in store or search
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${app.packageName}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(marketIntent)
                true
            }
        } catch (e: Exception) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${app.packageName}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
                true
            } catch (e2: Exception) {
                false
            }
        }
    }

    fun openAppDetails(app: AppItem) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", app.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to general settings
            openSettings()
        }
    }

    fun openWifiSettings() {
        try {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            openSettings()
        }
    }

    fun openBluetoothSettings() {
        try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            openSettings()
        }
    }

    fun openSettings() {
        try {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun openHomeSettings() {
        val attempts = listOf(
            Intent(Settings.ACTION_HOME_SETTINGS),
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (intent in attempts) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return
            } catch (_: Exception) {}
        }
    }
}
