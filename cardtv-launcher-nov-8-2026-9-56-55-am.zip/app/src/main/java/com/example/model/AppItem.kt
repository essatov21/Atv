package com.example.model

import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonPurple

enum class CardSuit(val symbol: String, val displayName: String, val primaryColor: Color) {
    SPADES("♠", "Пики", NeonCyan),
    HEARTS("♥", "Черви", NeonCrimson),
    DIAMONDS("♦", "Бубны", NeonGold),
    CLUBS("♣", "Трефы", NeonEmerald)
}

enum class AppCategory(val title: String) {
    ALL("Все"),
    FAVORITES("Избранное"),
    MEDIA("Медиа"),
    STREAMING("Кино и ТВ"),
    GAMES("Игры"),
    TOOLS("Система и Утилиты")
}

data class AppItem(
    val id: String,
    val label: String,
    val packageName: String,
    val activityName: String? = null,
    val iconDrawable: Drawable? = null,
    val versionName: String = "1.0",
    val versionCode: Long = 1L,
    val isTvApp: Boolean = false,
    val isSystemApp: Boolean = false,
    val isFavorite: Boolean = false,
    val cardSuit: CardSuit = CardSuit.SPADES,
    val cardRank: String = "A",
    val neonColor: Color = NeonCyan,
    val category: AppCategory = AppCategory.ALL,
    val installDate: String = "",
    val lastUpdateTime: String = "",
    val description: String = ""
)
